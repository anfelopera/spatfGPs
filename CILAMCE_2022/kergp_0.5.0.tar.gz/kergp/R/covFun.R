# ## see Chambers 'Software for Data Analysis", p 338
setClassUnion("optCharacter", c("character", "NULL"))

setClass("covFun",   	
         representation(
           kernel = "function",
           groupList = "list",            ## list with the structure of the functional input
           hasGrad = "logical",
           label = "character",
           d = "integer",                 ## nb of functional inputs
           inputNames = "optCharacter",   ## spatial var names length d
           parLower = "numeric",          ## lower bound on par's
           parUpper = "numeric",          ## upper bound on par's
           par  = "numeric",              ## params values
           parN = "integer",              ## number of par
           kernParNames  = "character"   ## depending on kernel
           # Psi = "matrix"                 ## integrated Gram matrix of the basis
         ),
         validity = function(object){
           if (length(object@kernParNames) != object@parN) {
             stop("Incorrect number of parameter names")
           }
         })


## *****************************************************************************
##' Creator for the class \code{"covFun"}.
##'
##' In progress by Andres F. Lopez-Lopera
##'
##' @title Creator for the Class \code{"covFun"}
##' 
##' @param hasGrad Logical indicating whether the \code{kernel}
##' function returns the gradient w.r.t. the vector of parameters as
##' a \code{"gradient"} attribute of the result. See \bold{Details}
##' 
##' @param inputs Character. Names of the inputs.
##'
##' @param d Integer. Number of inputs. 
##' 
##' @param parNames. Names of the parameters. By default, ranges
##' are prefixed \code{"theta_"} in the non-iso case and the range is
##' names \code{"theta"} in the iso case.
##' 
##' @param par Numeric values for the parameters. Can be \code{NA}.
##'
##' @param parLower Numeric values for the lower bounds on the
##' parameters. Can be \code{-Inf}.
##'
##' @param parUpper Numeric values for the uppper bounds on the
##' parameters. Can be \code{Inf}.
##'
##' @param ... Other arguments passed to the method \code{new}.
##'
##' @return An object with class \code{"covFun"}.
##' 
##' 
covFun <- function(kernel,
                   hasGrad = FALSE,
                   inputs = "u",
                   groupList = NULL, 
                   d = length(inputs),
                   parNames,
                   par = NULL,
                   parLower = NULL,
                   parUpper = NULL,
                   label = "covFun", ...) {
  
  if (is.null(par))
    par <- as.numeric(rep(NA, length(parNames)))
  if (is.null(parLower))
    parLower <- as.numeric(rep(-Inf, length(parNames)))
  if (is.null(parUpper))
    parUpper <- as.numeric(rep(Inf, length(parNames)))
  
  if (missing(d) & missing(inputs))
    stop("at least one of 'd' or 'inputs' must be provided")
  if (length(inputs) != d)
    stop("'d' must be equal to 'length(inputs)'")
  
  new("covFun", 
      kernel = as.function(kernel),
      groupList = as.list(groupList),
      hasGrad = as.logical(hasGrad),
      label = as.character(label),
      d = as.integer(d),
      inputNames = as.character(inputs),
      kernParNames = as.character(parNames),
      par = as.numeric(par),
      parLower = as.numeric(parLower),
      parUpper = as.numeric(parUpper),
      parN = length(par),    
      ...)
  
}  # TODO : check that the kernel has 2 (eg : brownian) or 3 arguments (parameterised kernel).


##  npar method for class "covFun".
setMethod("npar",
          signature = signature(object = "covFun"),
          definition = function(object,  ...){
            object@parN
          })

##***********************************************************************
## CAUTION:  when 'type' is a vector and 'as' is "list" or "matrix"
## elements are returned in the order given by 'type'
## which might differ from the standard parameter order.
##
## o 'type' can be "all", or can be a character vector describing a
##          subset of the union U(kernParNaems, "var")
## 
## o 'as'   can be "vector", "list", or "matrix"
##
##***********************************************************************
setMethod("coef", 
          signature = signature(object = "covFun"), 
          definition = function(object){         
            res <- object@par
            names(res) <- object@kernParNames
            res
          })

##***********************************************************************
## Replacement method
##
## XXX check validity???
##
## NOT WRITTEN YET
##
##**********************************************************************
setMethod("coef<-", 
          signature = signature(object = "covFun", value = "numeric"),
          definition = function(object, ..., value){
            if (length(value) != object@parN) {
              stop(sprintf("'value' has length %d but must have length %d",
                           length(value), object@parN))
            }
            object@par[] <- value
            object
          })

##***********************************************************************
## Methods to get/set the parameter bounds?
## One could set bounds by group: range, shape etc.
##
##***********************************************************************
setMethod("coefLower", 
          signature = signature(object = "covFun"),
          definition = function(object){
              res <- object@parLower
              names(res) <- object@kernParNames
              res         
          })

setMethod("coefLower<-",
          signature = signature(object = "covFun"),
          definition = function(object, ..., value){
            if (length(value) != object@parN) {
              stop(sprintf("'value' must have length %d", object@parN))
            }
            object@parLower[] <- value
            object   
          })

setMethod("coefUpper", 
          signature = signature(object = "covFun"),
          definition = function(object){
              res <- object@parUpper
              names(res) <- object@kernParNames
              res            
          })

setMethod("coefUpper<-",
          signature = signature(object = "covFun"),
          definition = function(object, ..., value){
            if (length(value) != object@parN) {
              stop(sprintf("'value' must have length %d", object@parN))
            }
            object@parUpper[] <- value
            object   
          })

##***********************************************************************
## coercion method to cleanly extract the kernel slot
##***********************************************************************
setAs("covFun", "function", function(from) from@kernel)


##***********************************************************************
## scores method 
## 
## Note that the scores method can only be used when the weight matrix
## is known, which requires an evaluation of 'covMat'.
##
## To avoid that, the covariance matrix could be passed to the 'scores'
## method, whith a previous analysis of the kind of object (whether
## it accepts matrix or not)
##
##***********************************************************************
setMethod("scores",
          signature = "covFun", 
          definition = function(object, X, weights,  ...) {

            X <- as.matrix(X)
            if (any(is.na(X))) stop("'X' must not contain NA elements") 
            
            groupList <- object@groupList
            f <- groupList[X]
            attributes(f) <- attributes(groupList)
            dCov <- attr(object@kernel(f, f, coef(object)), "gradient")
            
            n <- nrow(X)
            if (any(dim(dCov) != c(n, n, npar(object)))) {
              stop("\"gradient\" attribute with wrong dimension")  
            }
            lt <- lower.tri(matrix(NA, nrow = n , ncol = n), diag = TRUE)
            agFun <- function(mat) sum(weights * mat[lt])
            scores <- apply(dCov, MARGIN = 3L, FUN = agFun)
            return(scores)
          })


##***********************************************************************
## The 'show' method must show the kernel name and parameter structure.
## It should also provide information of the parameterisation of the
## structure itself (sharing of the parameters across inputs).
##
##***********************************************************************
setMethod("show", 
          signature = signature(object = "covFun"), 
          definition = function(object){
            cat("'User' covariance kernel for functional inputs\n")
            argNames <- names(formals(object@kernel))
            cat(paste("o Description:"), object@label, "\n")
            cat(sprintf("o Dimension 'd' (nb of inputs): %d\n", object@d))
            cat(paste("o Parameters: ",
                      paste(sprintf("\"%s\"", object@kernParNames),
                            collapse = ", "),
                      "\n", sep = ""))
            cat(sprintf("o Number of parameters: %d\n", object@parN))
            if (object@hasGrad) {
              cat("o Analytical gradient is provided.\n")
            }
            cat("o Param. values: \n")
            co <- cbind(coef(object), coefLower(object), coefUpper(object))
            colnames(co) <- c("Value", "Lower", "Upper")
            print(co)
          })


## *************************************************************************
## covMat method
## *************************************************************************
setMethod("covMat",
          signature = signature(object = "covFun"), 
          definition = function(object, X, Xnew,
                                compGrad = hasGrad(object),
                                groupList = object@groupList,
                                checkNames = NULL, index = 1L, ...) {
            
            X <- as.matrix(X)
            
            isXnew <- !is.null(Xnew)
            if (isXnew) compGrad <- FALSE
            
            if (is.null(checkNames)) {
              checkNames <- TRUE
              if (object@d == 1L) {
                if (ncol(X) == 1L) {
                  checkNames <- FALSE
                }
              }
            }
            
            if (checkNames) X <- checkX(object, X = X)
            if (any(is.na(X))) stop("'X' must not contain NA elements")
            
            ## Building up the functional inputs according to categorical indices
            # f <- groupList[X]
            # attributes(f) <- attributes(groupList)
            u <- unique(X)
            # g <- groupList[u] # a bug
            g <- groupList
            # g$f <- lapply(lapply(lapply(groupList$f, "t"), "[", T, u), "t")
            g$coef <- groupList$coef[u]
            attributes(g) <- attributes(groupList)
            
            if (isXnew){
              Xnew <- as.matrix(Xnew)
              if (checkNames) Xnew <- checkX(object, X = Xnew)
              if (ncol(X) != ncol(Xnew))
                stop("'X' and 'Xnew' must have the same number of columns")
              if (any(is.na(Xnew))) stop("'Xnew' must not contain NA elements") 
              
              # fnew <- groupList[Xnew]
              # attributes(fnew) <- attributes(groupList)
              unew <- unique(Xnew)
              # gnew <- groupList[unew] # a bug
              gnew <- groupList
              # gnew$f <- lapply(lapply(lapply(groupList$f, "t"), "[", T, unew), "t")
              gnew$coef <- groupList$coef[unew] 
              if ('distff' %in% names(g) & !is.null(g$distff)) 
                g$distff <- gnew$distff <- lapply(g$distff[u], "[", unew)
              attributes(gnew) <- attributes(groupList)
            } else {
              Xnew <- X
              if ('distff' %in% names(g) & !is.null(g$distff))
                g$distff <- lapply(g$distff[u], "[", u)
              gnew <- g
            }

            CovG <- object@kernel(g, gnew, coef(object))
            # Cov <- CovG[names(g$coef), names(gnew$coef)]
            Cov <- as.matrix(CovG[names(groupList$coef[X]), names(groupList$coef[Xnew])])

            # Cov <- object@kernel(f, fnew, coef(object))
            # ## Warning: the computation of "Cov" is not optimal since the distances
            # ## between functional spaces are repeatedly calculated in order to be in
            # ## agreement with to the structure required by "kergp". One can precompute
            # ## only once all those distances and call them if necessary.
            
            if (!compGrad) {
              attr(Cov, "gradient") <- NULL
            } else {
              attr(Cov, "gradient") <- attr(CovG, "gradient")[names(groupList$coef[X]), names(groupList$coef[Xnew]), ]
              if ((index < 1L) || (index > object@parN)) {
                stop("when 'compGrad' is TRUE, 'index' must",
                     " be between 1 and npar(object)")
              }
            }
            return(Cov) 
          })

## *************************************************************************
## varVec method: compute the variance vector.
## *************************************************************************
setMethod("varVec",
          signature = signature(object = "covFun"), 
          definition = function(object, X, groupList = object@groupList, compGrad = FALSE, 
                                checkNames = NULL, index = -1L, ...) {
            
            X <- as.matrix(X)

            if (is.null(checkNames)) {
              checkNames <- TRUE
              if (object@d == 1L) {
                if (ncol(X) == 1L) {
                  checkNames <- FALSE
                }
              }
            }
            
            if (checkNames) X <- checkX(object, X = X)
            if (any(is.na(X))) stop("'X' must not contain NA elements")

            
            
            ## Building up the functional inputs according to categorical indices
            # f <- groupList[X]
            # attributes(f) <- attributes(groupList)
            u <- unique(X)
            # g <- groupList[u] # a bug
            g <- groupList
            # g$f <- lapply(lapply(lapply(groupList$f, "t"), "[", T, u), "t")
            g$coef <- groupList$coef[u]
            if ('distff' %in% names(g) & !is.null(g$distff))
              g$distff <- lapply(g$distff[u], "[", u)
            attributes(g) <- attributes(groupList)
            
            CovG <- object@kernel(g, g, coef(object))
            # Cov <- CovG[names(g$coef), names(g$coef)]
            Cov <- CovG[names(groupList$coef[X]), names(groupList$coef[X])]
            Var <- diag(as.matrix(Cov)) 
            # attr(Var, "gradient") <- attr(CovG, "gradient")[X, X, ]
            
            # # myVar <- function(x) {
            # #   object@kernel(x, x, par = object@par)
            # # }            
            # # Var <- lapply(f, MARGIN = 1, myVar)
            # Var <- diag(object@kernel(f, f, object@par))
            # ## Warning: to be improved by applying "myVar" function over a list.
            
            if (!compGrad) {
              attr(Var, "gradient") <- NULL
            } else {
              if ((index < 1L) || (index > object@parN)) {
                warning("Bad index passed to 'covMat' with 'gradComp = TRUE'. ",
                        "Setting 'gradComp' to FALSE.")
              }
            }
            return(Var) 
          })

## **********************************************************************
## Check that the FUNCTIONAL design matrix X is compatible with the
## covariance object This is quite different form the continuous input
## case, because one has to check the content of 'X', and not only the
## input names.
## **********************************************************************
setMethod("checkX",
          signature = signature(object = "covFun", X = "matrix"),
          definition = function(object, X, strict = FALSE, ...){
            iN <- inputNames(object)
            if (strict) {
              if (length(iN) != ncol(X) || !all(iN == colnames(X)) )
                stop("colnames(X) and inpuNames(object) must be identical")
            }
            if ( !all(inputNames(object) %in% colnames(X)) )
              stop("all the elements of inputNames(object) must be",
                   " in colnames(X)")
            X[ , iN, drop = FALSE] 
          })

setMethod("checkX",
          signature = signature(object = "covFun", X = "data.frame"),
          definition = function(object, X, strict = FALSE, ...){
            iN <- inputNames(object)
            if (strict) {
              if (length(iN) != ncol(X) || !all(iN == colnames(X)) )
                stop("colnames(X) and inpuNames(object) must be identical")
            }
            if ( !all(inputNames(object) %in% colnames(X)) )
              stop("all the elements of inputNames(object) must be",
                   " in colnames(X)")
            X[ , iN, drop = FALSE] 
          })
