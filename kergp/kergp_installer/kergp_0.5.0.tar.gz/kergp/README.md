
`kergp` Gaussian Process Laboratory
-----------------------------------

### NEWS from kergp_0.4.0 (available on CRAN)
- Ordinal kernels: Those based on cdf warping functions are now implemented.
- Group kernels: Groups of size 1 are now accepted.

### Cloning the repository

If you do not have yet a local `kergp` repository, use `git clone` to clone the `kergp` repository

``` bash
git clone https://github.com/ChaireOQUAIDO/kergp
```

This will create a `kergp` subdirectory of the current directory, i.e. the directory from which the git command was issued.

### Installation on Unix and MacOs systems

With these sytems you can install a package from its source. Move to the parent directory of your cloned repository and use the following command from a terminal to create a tarball source file

``` bash
R CMD build kergp
```

This will produce a source tarball `kergp_x.y.z` where `x`, `y` and `z` stand fro the major, minor and patch version numbers. Then you can install from a command line

``` bash
R CMD INSTALL kergp_x.y.z
```

Note that you must also have all the packages required by **kergp** installed.

If you are using the **RStudio** IDE, you can alternatively use menus.

### Install and pre-compile for Windows

In order to install the package from its source, you must have a suitable Windows plateform with [Rtools](https://cran.r-project.org/bin/windows/Rtools) installed. Then you can proceed as Unix or MacOS users, with a `build` step from command line.

If you can not (or do not want to) install the **Rtools** you may get a trusted binary from a friend or collegue next to you.

If you have the **Rtools** installed, you can create a binary. Using a terminal, move if necessary by using `cd` to the directory containing the source tarball and R command, and then type

``` bash
R CMD INSTALL --build kergp_x.y.z
```

This will create a `.zip` file that can be used on a Windows plateform which may not be equipped with *Rtools*. For instance, with **RStudio** you can use the menu `Tools/Install Packages` and select `Install from:`.
