myGaussFunRVec <- function(x1, x2, par) { 
  # x1, x2 : matrices with same number of columns 'd' (dimension)
  n <- nrow(x1)
  d <- ncol(x1)     
  SS2 <- 0  
  for (j in 1:d){
    Aj <- outer(x1[ , j], x2[ , j], "-")
    Hj2 <- (Aj / par[1])^2
    SS2 <- SS2 + Hj2
  }
  D2 <- exp(-SS2)
  kern <- par[2] * D2 + 1e-6*diag(nrow(D2))
  D1 <- 2 * kern * SS2 / par[1] 
  attr(kern, "gradient") <- list(theta = D1,  sigma2 = D2)
  
  return(kern)
}

d <- 1

myGaussRVec <- covMan(
  kernel = myGaussFunRVec,
  hasGrad = TRUE,
  acceptMatrix = TRUE,
  d = d,
  parLower = c(theta = 0.0, sigma2 = 0.0),
  parUpper = c(theta = Inf, sigma2 = Inf),
  parNames = c("theta", "sigma2"),
  label = "Gaussian kernel: vectorised R implementation"
)

n <- 100; p <- d + 1
X <- matrix(runif(n * d), nrow = n)
colnames(X) <- inputNames(myGaussRVec)
design <- data.frame(X)
coef(myGaussRVec) <- myPar <- c(theta = 0.5, sigma2 = 2)
myGp <- gp(formula = y ~ 1, data = data.frame(y = rep(0, n), design), 
           cov = myGaussRVec, estim = TRUE, noise = TRUE, trace = 3, compGrad = FALSE)
