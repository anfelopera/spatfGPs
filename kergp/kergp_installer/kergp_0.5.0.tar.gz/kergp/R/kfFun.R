#### internal functions required for functional kernels ####
# added on 2020-04-17 by Andres F. Lopez-Lopera
dist2ffvec <- function(f1, f2 = f1, Psi) {
  # f1, f2 = list with functional replicates (coefficients)
  # Psi = integrated Gram matrix of the basis
  nf <- length(f1)
  dcoeff <- Map("-", f1, f2)
  dist2ff <- sapply(seq(nf),
                    function(x) {diag(t(dcoeff[[x]]) %*% Psi[[x]] %*% dcoeff[[x]])})
  return(dist2ff)
}

dist2FFvec <- function(F1, F2 = F1, Psi) {
  # F1, F2 = list with functional replicates (coefficients)
  # Psi = Gram matrix of the basis
  nfs1 <- length(F1)
  nfs2 <- length(F2)
  dist2 <- vector("list", nfs1)
  for (i in 1:nfs1) {
    temp <- vector("list", nfs2)
    for (j in 1:nfs2) {
      temp[[j]] <- dist2ffvec(F1[[i]], F2[[j]], Psi)
    }
    dist2[[i]] <- temp
  }
  return(dist2)
}

dist2f_scaled <- function(f1, f2 = f1, theta, Psi, preDist2ff = NULL) {
  # f1, f2 = list with functional replicates (coefficients)
  # Psi = integrated Gram matrix of the basis
  # theta = lengthscale parameters
  # preDist2ff = precomputed distances

  nf <- length(f1)
  if (length(theta) != nf)
    stop('inconsistent dimensions')

  if (!is.null(preDist2ff)) {
    dist2ff <- preDist2ff/theta^2
  } else {
    dcoeff <- Map("-", f1, f2)
    # # dist2ff <- diag(t(dcoeff) %*% Psi %*% dcoeff)/theta^2
    # dist2ff <- rep(NaN, nf)
    # for (i in 1:nf)
    #   dist2ff[i] <- diag(t(dcoeff[,i]) %*% Psi[[i]] %*% dcoeff[,i])/theta[i]^2
    dist2ff <- sapply(seq(nf),
                      function(x) {diag(t(dcoeff[[x]]) %*% Psi[[x]] %*% dcoeff[[x]])/theta[x]^2})
  }

  # computing the total distance
  dist2 <- sum(dist2ff)

  # computing gradients
  ddist2ff <- -2*dist2ff/theta
  names(ddist2ff) <- names(theta)
  attr(dist2, "gradient") <- ddist2ff
  # dimf <- length(theta)
  # hfun <- parse(text = paste("list(", paste("theta_f", 1:dimf, " = ddist2ff[",
  #                              1:dimf, "]", sep = "", collapse = ", "), ")"))
  # attr(dist2, "gradient") <- eval(hfun)
  return(dist2)
}

dist2F_scaled <- function(F1, F2 = F1, theta, Psi, distFF = NULL) {
  # F1, F2 = list with realisations of functional inputs (coefficients, basis)
  # Psi = Gram matrix of the basis
  # theta = lengthscale parameters
  # distFF = list with precomputed distances
  nfs1 <- length(F1)
  nfs2 <- length(F2)
  dimf <- length(theta)
  dist2 <- matrix(0, nfs1, nfs2)
  ddist2 <- array(NA, dim = c(nfs1, nfs2, dimf),
                  dimnames = list(names(F1), names(F2), names(theta)))

  for (i in 1:nfs1) {
    for (j in 1:nfs2) {
      if (!is.null(distFF)) {
        temp <- dist2f_scaled(F1[[i]], F2[[j]], theta, Psi, distFF[[i]][[j]])
      } else {
        temp <- dist2f_scaled(F1[[i]], F2[[j]], theta, Psi)
      }
      dist2[i, j] <- temp
      ddist2[i, j, ] <- attr(temp, "gradient")
    }
  }
  attr(dist2, "gradient") <- ddist2
  # hfun <- parse(text = paste("list(", paste("theta_f", 1:dimf, " = ddist2[ , , ",
  #                                          1:dimf, "]", sep = "", collapse = ", "), ")"))
  # attr(dist2, "gradient") <- eval(hfun)
  return(dist2)
}
